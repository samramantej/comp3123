const express = require('express');
const app = express();
const SERVER_PORT = 3000;

// Middleware to parse JSON body
app.use(express.json());

// Route for root "/"
app.get('/', (req, res) => {
  res.send('<h1>Hello World</h1>');
});

// Route for "/about"
app.get('/about', (req, res) => {
  res.send('<h1>About Us</h1>');
});

// Route for "/contact"
app.get('/contact', (req, res) => {
  res.send('<h1>Contact Us</h1>');
});

// GET request for "/hello"
app.get('/hello', (req, res) => {
  res.status(200).send('Hello Express JS');
});

// GET request for "/user" with query parameters
app.get('/user', (req, res) => {
  const firstname = req.query.firstname || 'Pritesh';
  const lastname = req.query.lastname || 'Patel';
  res.status(200).json({ firstname, lastname });
});

app.post('/user/:firstname/:lastname', (req, res) => {
    console.log('POST request received');
    const { firstname, lastname } = req.params;
    res.status(201).json({ firstname, lastname });
  });
  

// Start the server
app.listen(SERVER_PORT, () => {
  console.log(`Server is running on http://localhost:${SERVER_PORT}`);
});
