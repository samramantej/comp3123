import React from 'react';

function Welcome() {
  return <p>Welcome to React Lab Week 09. Let's learn about components, props, and state!</p>;
}

export default Welcome;
