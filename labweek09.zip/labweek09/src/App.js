import React from 'react';
import './App.css';
import Greetings from './Greetings';
import SayHello from './SayHello';
import Welcome from './Welcome';
import logo from './logo.svg';

function App() {
  return (
    <div className="App">
      <img src={logo} alt="React Logo" className="logo" />
      <h1>Welcome to Fullstack Development - I</h1>
      <p>React JS Programming Week09 Lab Exercise</p>
      <p>101410416</p>
      <p>Mantej singh samra</p>
      <p>George Brown College, Toronto</p>
    
    </div>
  );
}

export default App;
