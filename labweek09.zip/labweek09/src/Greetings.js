import React from 'react';

function Greetings({ name }) {
  return <h2>Hello, {name}! Welcome to our React Lab.</h2>;
}

export default Greetings;
