//qUES 1
const greeter = (myArray) => {
    const greetText = 'hello ';
    for (const item of myArray) {
        console.log(`${greetText}${item}`);
    }
};

greeter(['randy savage', 'ric flair', 'hulk hogan']);

//qUES 2
const capitalize = (str) => {
    const [firstChar, ...rest] = str;
    return `${firstChar.toUpperCase()}${rest.join('')}`;
};

console.log(capitalize('foobar'));
console.log(capitalize('nodejs'));

//QUES 3
const colors = ['red', 'green', 'blue'];
const capitalizedColors = colors.map(capitalize);

console.log(capitalizedColors);

//ques 4
const filterLessThanTwenty = (arr) => {
    return arr.filter(value => value >= 20);
};
const values = [1, 60, 34, 30, 20, 5];
console.log(filterLessThanTwenty(values)); 

//ques 5
const array = [1, 2, 3, 4];
const calculateSum = (arr) => arr.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
const calculateProduct = (arr) => arr.reduce((accumulator, currentValue) => accumulator * currentValue, 1);

console.log(calculateSum(array));
console.log(calculateProduct(array)); 

//ques 6
class Car {
    constructor(model, year) {
        this.model = model;
        this.year = year;
    }

    details() {
        return `${this.model} engine ${this.year}`;
    }
}

class Sedan extends Car {
    constructor(model, year, balance) {
        super(model, year);
        this.balance = balance;
    }

    info() {
        return `${this.model} has a balance of $${this.balance.toFixed(2)}`;
    }
}

const car2 = new Car('pontiac firebird', 1976);
console.log(car2.details());

const sedan = new Sedan('volvo', 2018, 30000);
console.log(sedan.info());



